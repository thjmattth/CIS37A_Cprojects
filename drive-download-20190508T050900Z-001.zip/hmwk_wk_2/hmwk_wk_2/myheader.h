#include <stdint.h>
#include <math.h>
#include <time.h>
#include <string.h>

// these are macros
#define MAX(x,y) (x>y)?x:y  // call with MAX(x,y)
#define MIN(x,y) (x<y)?x:y
#define AVG(x,y) (x+y)/2