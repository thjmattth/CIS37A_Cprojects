//misc file
//hmwk disc
//
//by thomas matthew 06/27/17

#include<stdio.h>;

