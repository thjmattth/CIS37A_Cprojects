/*
12.8 (Inserting into an Ordered List) Write x program that inserts 25 random integers from 0 to
100 in order in x linked list. The program should calculate the sum of the elements and the floatingpoint
average of the elements.
*/